// TopCompanies_item
$('.owl-carousel.TopCompanies_slider').owlCarousel({
    items:1,
    loop:true,
    nav:false,
    dots:true,
})

// 
$('.owl-carousel.client_slider').owlCarousel({
    items:1,
    loop:true,
    nav:true,
    dots:false,
})